@echo off
setlocal
rem Use the portable CPU renderer on systems without a working OpenGL driver.
set GALLIUM_DRIVER=llvmpipe
set LP_NUM_THREADS=1
start "" "%~dp0software\1loop.exe" %*
